const recipes = document.querySelector('#recipes');

$(document).ready(function(){
    $('.sidenav').sidenav();
});

document.addEventListener('DOMContentLoaded', function() {
    var elems = document.querySelectorAll('.fixed-action-btn');
    var instances = M.FloatingActionButton.init(elems, {
      hoverEnabled: false
    });
  });


// render recipes data
const renderRecipe = (data, id) => {
  const html = `
  <li class="collection-item avatar" data-id="${id}">
    <img src="images/chorizo-mozarella-gnocchi-bake-cropped.jpg" alt="" class="circle">
    <span class="title">${data.title}</span>
    <p>
      ${data.ingredients}
    </p>
    
  </li>
  `;

  recipes.innerHTML += html;
}

// remove recipes from DOM

// const removeRecipe = id => {
//   const recipe = document.querySelector(`.recipe[data-id=${id}]`);
//   recipe.remove();
// }